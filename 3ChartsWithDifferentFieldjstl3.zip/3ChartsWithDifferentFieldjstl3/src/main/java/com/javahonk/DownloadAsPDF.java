package com.javahonk;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.xhtmlrenderer.pdf.ITextRenderer;

import com.pdfcrowd.Client;
import com.pdfcrowd.PdfcrowdError;

public class DownloadAsPDF extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			FileOutputStream fileStream;

			// create an API client instance
			Client client = new Client("Vikaskapadiya66", "73b5e230b89e33f3c965c37ad4d5e5e9");
			// convert an HTML file
			
			fileStream = new FileOutputStream("d://file.pdf");
			client.convertFile("D:/SPRINGEL/3ChartsWithDifferentFieldjstl3/src/main/webapp/dashboard.jsp", fileStream);
			fileStream.close();

			// retrieve the number of credits in your account
			Integer ncredits = client.numTokens();
		} catch (PdfcrowdError why) {
			System.err.println(why.getMessage());
		} catch (IOException exc) {
			// handle the exception
		}
	}// doGet

}// class
